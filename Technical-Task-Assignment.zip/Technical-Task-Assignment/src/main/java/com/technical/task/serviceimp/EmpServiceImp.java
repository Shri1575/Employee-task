package com.technical.task.serviceimp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.technical.task.daos.SalaryRepository;
import com.technical.task.dtos.EmployeeDetailsResponse;
import com.technical.task.dtos.EmployeeRequest;
import com.technical.task.dtos.SalaryDetails;
import com.technical.task.model.EmpSalary;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.technical.task.daos.EmpDao;
import com.technical.task.dtos.EmployeeDto;
import com.technical.task.exceptions.ResouceNotFoundException;
import com.technical.task.model.Employee;
import com.technical.task.service.EmpServicei;

@Service
public class EmpServiceImp implements EmpServicei {

    @Autowired
    private EmpDao empdao;
    @Autowired
    private ModelMapperService modelMapperService;

    @Autowired
    private SalaryRepository salaryRepository;

    private static final Logger LOG = LogManager.getLogger(EmpServiceImp.class);

    @Override
    public String addEmployeeDetails(EmployeeRequest employeeRequest) {
        Employee employee = new Employee();
        employee.setEmployeeAge(employeeRequest.getAge());
        employee.setEmployeeName(employeeRequest.getEmployeeName());
        empdao.save(employee);
        return "employeeAddedSuccess";
    }

    @Override
    public String addEmployeeSalary(EmployeeRequest employee) {
        if (empdao.existsById(employee.getEmployeeId())) {
            EmpSalary empSalary = new EmpSalary();
            empSalary.setEmployeeId(empdao.findById(employee.getEmployeeId()).get());
            empSalary.setEmployeeSalary(employee.getSalary());
            empSalary.setMonth(employee.getMonth());
            salaryRepository.save(empSalary);
            return "Salary Added";
        }
        throw new ResouceNotFoundException("No Employee Found");

    }

    @Override
    public EmployeeDto getEmployeeDetailsById(Long employeeId) {

        Boolean empExist = empdao.existsById(employeeId);
        if (empExist) {
            Employee emp = empdao.findById(employeeId).get();
            return modelMapperService.mappedToEmployeeDto(emp);
        } else {
            throw new ResouceNotFoundException("Employee Does Not Exist");
        }
    }

    @Override
    public void deleteEmployeeDetailsById(Long employeeId) {
        boolean empExist = empdao.existsById(employeeId);
        if (empExist) {
            empdao.deleteById(employeeId);
        } else {
            throw new ResouceNotFoundException("Employee does not exist");
        }

    }

    @Override
    public EmployeeDto updateEmployeeDetails(Employee employee) {
        if (empdao.existsById(employee.getEmployeeId())) {
            LOG.info("EmpServiceImp class AddEmployeeDetails Method");
            Employee emp = empdao.save(employee);
            return modelMapperService.mappedToEmployeeDto(emp);

        } else {
            throw new ResouceNotFoundException("EmployeeId id is does not Exists");
        }
    }

    @Override
    public EmployeeDto findEmployeeByNameAndSalary(String employeeName, double salary) {

        return empdao.findByEmployeeNameAndEmpSalary(employeeName, salary);
    }

    @Override
    public HashMap<String, Object> getAllEmployeeDetailsInJsonFormat() {
        HashMap<String, Object> response = new HashMap<>();
        List<Employee> employees = empdao.findAll();
        employees.forEach(employee -> {
            response.put(employee.getEmployeeName(), getAllEmployeeDetails(employee));
        });
        return response;
    }



    @Override
    public List<SalaryDetails> getAllEmployeeDetails(Employee employee) {
        try {
            List<SalaryDetails> employeeSalaryDetails = new ArrayList<>();
            employee.getEmpSalary().forEach(empSalary -> {
                employeeSalaryDetails.add(new SalaryDetails(empSalary));
            });
            return employeeSalaryDetails;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


}
