package com.technical.task.dtos;

import com.technical.task.model.EmpSalary;
import com.technical.task.model.Employee;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SalaryDetails {
    private Double salary;
    private String month;

    public SalaryDetails(EmpSalary empSalary) {
        this.salary = empSalary.getEmployeeSalary();
        this.month = empSalary.getMonth();

    }
}
