package com.technical.task.daos;

import com.technical.task.model.EmpSalary;
import org.springframework.data.repository.CrudRepository;

public interface SalaryRepository extends CrudRepository<EmpSalary, Long> {
}
