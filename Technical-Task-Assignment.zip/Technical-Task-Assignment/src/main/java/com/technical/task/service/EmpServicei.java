package com.technical.task.service;

import java.util.HashMap;
import java.util.List;

import com.technical.task.dtos.EmployeeDetailsResponse;
import com.technical.task.dtos.EmployeeDto;
import com.technical.task.dtos.EmployeeRequest;
import com.technical.task.dtos.SalaryDetails;
import com.technical.task.model.Employee;

public interface EmpServicei {

    // add Employee Details
    String addEmployeeDetails(EmployeeRequest employee);

    // get Employee Details
    EmployeeDto getEmployeeDetailsById(Long employeeId);

    // delete Employee by employee id
    void deleteEmployeeDetailsById(Long employeeId);

    //update employee By employee id
    EmployeeDto updateEmployeeDetails(Employee employee);

    //get All List of Employee
    List<SalaryDetails> getAllEmployeeDetails(Employee employee);

    EmployeeDto findEmployeeByNameAndSalary(String employeeName, double salary);

    HashMap<String, Object> getAllEmployeeDetailsInJsonFormat();

    String addEmployeeSalary(EmployeeRequest employee);
}
