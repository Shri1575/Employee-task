package com.technical.task.dtos;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmployeeRequest {
    private String employeeName;
    private Integer age;
    private long employeeId;
    private Double salary;
    private String month;
}
