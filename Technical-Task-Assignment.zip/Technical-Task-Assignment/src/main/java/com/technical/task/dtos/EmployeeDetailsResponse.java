package com.technical.task.dtos;

import com.technical.task.model.Employee;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmployeeDetailsResponse {
    private String employeeName;
    private String salary;
    private String month;

    public EmployeeDetailsResponse(Employee employee) {

    }
}
