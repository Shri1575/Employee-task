package com.technical.task.exceptions;

public class ResouceNotFoundException extends RuntimeException{

	public ResouceNotFoundException(String massage) {
		super(massage);
	}

}
